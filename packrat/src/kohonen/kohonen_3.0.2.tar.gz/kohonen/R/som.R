"som" <- function (X, ...)
{
  supersom(list(X), ...)
}
